# 🥗 NutriLens

Scan a nutrition-facts label with your phone camera (or upload a photo) and
get instant, educational estimates of:

1. **Insulin Load** — an algorithmic proxy for how sharply a food is likely
   to spike insulin (based on the Food Insulin Index literature).
2. **Body-Fat % Projection** — a caloric-balance projection showing what
   this food's surplus/deficit, relative to your hourly metabolic burn,
   would theoretically equate to in stored/spared fat mass.

Built with **Streamlit**, **Pillow**, **pytesseract**, **pandas**, and
**numpy**. Works on desktop and mobile browsers, using `st.camera_input`
for native device-camera capture on phones.

> ⚠️ **This is an educational approximation tool, not a medical device.**
> It does not measure real blood insulin or real-time body composition.
> See [Scientific Basis & Limitations](#scientific-basis--limitations) below.

---

## Features

- 📷 **Camera or gallery upload** — `st.camera_input` opens the phone
  camera directly; a file uploader is provided as a fallback for gallery
  photos or desktop use.
- 🔍 **OCR label parsing** — extracts serving size, calories, carbs, fiber,
  sugars, protein, and fat via `pytesseract`, with tolerant regex parsing
  that handles common OCR noise (missing spaces, punctuation, decimal
  commas, varying label wording). Supports **English and Japanese
  (日本語)** labels in a single pass, including mixed-language labels.
- 📷 **Built for real camera photos, not just clean scans** — corrects
  EXIF orientation (phones tag rotation as metadata rather than rotating
  pixels, which silently defeats OCR on portrait photos), and tries
  multiple preprocessing variants (contrast/sharpen, Otsu binarization,
  plain grayscale) per photo, automatically keeping whichever one parses
  the most fields — this matters a lot under real-world lighting, glare,
  and slight blur.
- ✏️ **Manual override** — every OCR'd value lands in an editable
  `st.data_editor` table so users can correct misreads before calculating.
  If OCR finds nothing (blurry photo, no OCR engine installed, etc.), the
  app falls back cleanly to manual entry — it never crashes.
- 👤 **Smart profile defaults** — age, height, weight, and body-fat % can
  be left blank; the app fills gaps with literature-based baselines
  (BMI-based Deurenberg body-fat formula, gender-average default weight,
  etc.) and tells you exactly which fields were defaulted.
- 📏 **Metric or Imperial units** — kg/cm or lb/ft-in, your choice.
  Multiple servings supported (scale the whole label by portion size).
- 📊 **Clear visual output** — `st.metric`, `st.progress`, and color-coded
  categories for at-a-glance results.
- 💾 **Saved food database** — save any scanned/entered food with a name,
  category, optional brand, and free-form tags (SQLite, no external
  service needed). Search saved foods by any combination of those fields
  and load one back in a click, skipping OCR entirely on repeat foods.
- ⌨️ **Autocomplete everywhere** — every name/category/brand/tag field
  (both when saving and when searching) fuzzy-filters your existing
  values as you type, and lets you type a brand-new value if nothing
  matches, via Streamlit's `accept_new_options`.
- 🛡️ **Defensive engineering** — corrupted images, empty labels, zero
  weight/height, and unknown activity levels are all handled without
  crashing the app.

---

## Project structure

```
nutrilens/
├── app.py                     # Main Streamlit application (UI + orchestration)
├── modules/
│   ├── calculations.py        # Pure-Python metabolic/nutrition math (UI-independent)
│   ├── ocr_parser.py          # OCR text extraction + regex field parsing
│   ├── database.py            # SQLite CRUD + search for saved foods (UI-independent)
│   └── user_profile.py        # Sidebar UI for collecting profile inputs
├── tests/
│   ├── test_calculations.py   # 33 unit tests for the calculation engine
│   ├── test_ocr_parser.py     # 8 unit tests for label text parsing
│   └── test_database.py       # 29 unit tests for the food database
├── data/                      # Created automatically; holds nutrilens.db (gitignored)
├── .streamlit/
│   └── config.toml            # Theme + server configuration
├── requirements.txt           # Python dependencies
├── packages.txt               # System (apt) dependency: tesseract-ocr binary
├── .gitignore
└── README.md
```

The calculation engine (`modules/calculations.py`) and the database layer
(`modules/database.py`) have **zero Streamlit dependency**, so they can be
unit tested, reused in a CLI, or swapped into a different frontend
without modification.

---

## Running locally

```bash
# 1. Clone / copy this project, then create a virtual environment
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install Python dependencies
pip install -r requirements.txt

# 3. Install the Tesseract OCR binary (pytesseract is just a wrapper —
#    it needs the actual `tesseract` executable on your system), plus the
#    Japanese trained-data files for Japanese label support:
#    macOS:    brew install tesseract tesseract-lang
#    Ubuntu:   sudo apt-get install tesseract-ocr tesseract-ocr-jpn tesseract-ocr-jpn-vert
#    Windows:  https://github.com/UB-Mannheim/tesseract/wiki
#              (select "Japanese" in the installer's language options)

# 4. Run the app
streamlit run app.py
```

Open the URL Streamlit prints (typically `http://localhost:8501`). On your
phone, use the "Network URL" shown in the terminal (same Wi-Fi network) to
test camera capture on a real device.

---

## Deploying to Streamlit Community Cloud

1. Push this project to a GitHub repository.
2. On [share.streamlit.io](https://share.streamlit.io), create a new app
   pointing at `app.py`.
3. Streamlit Cloud automatically:
   - installs everything in `requirements.txt`, and
   - installs everything in `packages.txt` via `apt-get` — this is what
     provides the `tesseract-ocr` binary and the `tesseract-ocr-jpn` /
     `tesseract-ocr-jpn-vert` Japanese trained-data files that
     `pytesseract` calls out to. **Don't skip `packages.txt`** — without
     it, `pytesseract` will raise `TesseractNotFoundError` in the cloud
     environment (the app catches this gracefully and falls back to
     manual entry, but OCR won't work), and without the `-jpn` packages
     specifically, Japanese labels will silently fail to parse even
     though English labels work fine (the app shows a warning banner in
     this case, via `tesseract_japanese_available()`).

No secrets or API keys are required — everything runs locally in the
Streamlit process.

---

## How the predictions work

### 1. Metabolic baseline
- **BMI** = weight(kg) / height(m)²
- **Body Fat %** (Deurenberg formula, used only when not provided):
  `BF% = 1.20·BMI + 0.23·age − 10.8·genderFactor − 5.4` (Male=1, Female=0)
- **BMR** (Mifflin-St Jeor equation)
- **TDEE** = BMR × activity multiplier (1.2 / 1.375 / 1.55 / 1.725)

### 2. Insulin Load (Food Insulin Index proxy)
```
Insulin Load = Carbs − (0.5 × Fiber) + (0.56 × Protein) + (0.15 × Fat)
```
Scored against a reference: a standard 50g oral-glucose-tolerance-test
dose (~insulin load of 50) causes an illustrative ~30 µIU/mL spike in a
healthy adult. Your food's score is scaled proportionally against that
reference and bucketed into Low (<20) / Medium (20–45) / High (≥45).

### 3. Body-fat % change projection
1. **Gross calories** — uses the label's stated calorie count if present;
   otherwise derives it from macros via Atwater factors (protein/carbs
   4 kcal/g, fat 9 kcal/g, fiber ~2 kcal/g).
2. **Thermic Effect of Food (TEF)** — subtracts the energy your body
   burns digesting the food, using literature midpoints: protein 25%,
   carbs 10%, fat 1.5%.
3. **Net energy balance** — compares net metabolizable energy against
   your **hourly** TDEE baseline (TDEE ÷ 24).
4. **Fat-mass equivalent** — surplus/deficit ÷ 7700 kcal/kg (or
   ÷ 3500 kcal/lb), expressed as a percentage-point shift relative to
   your current body weight.

---

## Saved food database & search

Every scanned or manually-entered food can be saved with:

- **Name** (required)
- **Category** (optional — e.g. Dairy, Snack, Beverage; a starter list of
  common categories is suggested even before you've saved anything)
- **Brand** (optional)
- **Tags** (optional, any number — e.g. `high-protein`, `breakfast`,
  `gluten-free`)
- All 7 nutrition fields, per serving

Saved foods live in a local SQLite file at `data/nutrilens.db`, created
automatically on first run — no external database or API key needed.

**Searching:** the "🔎 Search your saved foods" panel lets you filter by
any combination of name, category, brand, and tags, then pick a match
from the results and load it straight into the current scan — skipping
the camera/OCR step entirely for foods you've logged before.

**Autocomplete:** every name/category/brand/tag field (both when saving
and when searching) is a fuzzy-filterable dropdown — start typing and
matching existing values narrow down live — and you can always type a
brand-new value if nothing matches, via `st.selectbox`/`st.multiselect`
with `accept_new_options=True`. Fields fall back to a plain text input
only when there are zero existing values yet to suggest.

> ⚠️ **Streamlit Community Cloud note:** that platform's filesystem is
> ephemeral, so `data/nutrilens.db` is wiped on every app restart or
> redeploy there. For durable multi-user persistence in production,
> replace the connection logic in `modules/database.py` with a hosted
> database (e.g. Postgres/Supabase) — the function signatures used by
> `app.py` (`save_food`, `search_foods`, `get_distinct_*`, etc.) can stay
> the same. Running locally, or on any host with a persistent disk, the
> SQLite file persists normally across restarts.

---

## OCR reliability on real camera photos

Clean, flat scans OCR easily; real phone photos are a different problem —
rotation metadata, uneven lighting, glare, and slight blur all degrade
recognition. Two concrete fixes address this:

1. **EXIF orientation correction.** Phones store rotation as EXIF
   metadata rather than rotating the actual pixels. Without correcting
   for it, a portrait photo can OCR as sideways or upside-down text —
   which reliably produces zero readable fields. `modules/ocr_parser.py`
   applies `ImageOps.exif_transpose()` before any OCR pass.
2. **Multiple preprocessing variants per photo.** A single fixed
   preprocessing recipe (e.g. "always binarize") helps some photos and
   hurts others, depending on lighting. Each photo is now processed three
   ways — contrast-enhanced + sharpened, Otsu-binarized (automatic
   threshold, robust to glare/shadow), and plain grayscale — each is
   OCR'd, and whichever result parses the most nutrition fields is kept.

**Japanese (日本語) label support** was added alongside these fixes:

- Both OCR backends run in combined English + Japanese mode
  (`lang="eng+jpn"` for tesseract, `["en", "ja"]` for EasyOCR), so mixed
  or either-language labels are read in one pass.
- Field-matching regexes were extended with Japanese label wording
  (エネルギー / たんぱく質 / 脂質 / 炭水化物 / 食物繊維 / 糖類, plus the
  蛋白質 kanji variant for protein) and are **whitespace-tolerant between
  every character** — Tesseract's Japanese engine frequently inserts
  stray spaces as word-segmentation artifacts (e.g. "エネルギー" → "エネ
  ルギー"), which would silently break an exact-string match.
- Full-width digits and punctuation (e.g. "１８０ｋｃａｌ", common with
  Japanese input methods) are normalized to standard ASCII via Unicode
  NFKC normalization before parsing.
- Some Japanese labels report a carbohydrate *breakdown* (糖質 + 食物繊維)
  instead of a single 炭水化物 total; when no direct total is found, it's
  derived automatically as 糖質 + 食物繊維.
- `tesseract_japanese_available()` checks whether the `jpn` trained-data
  file is actually installed and surfaces a clear warning in the app if
  it's missing, rather than silently reading Japanese labels as garbage.

---

## Scientific basis & limitations

This app deliberately uses **published, named formulas** (Mifflin-St
Jeor, Deurenberg, Food Insulin Index) rather than opaque black-box
predictions, so every number is traceable and explainable. That said:

- **A single meal does not measurably change your body-fat percentage.**
  Real adipose tissue changes occur over days-to-weeks of sustained
  caloric surplus/deficit, not within an hour of eating. The body-fat
  output here is a **projection/what-if indicator** — "if this food's
  caloric impact repeated every hour," not a literal forecast — and the
  app says so explicitly in the UI.
- **Insulin values are not measured blood levels.** True plasma insulin
  response depends on individual insulin sensitivity, meal composition
  interactions, glycemic index, time of day, and more — factors this
  algorithmic proxy does not capture.
- **OCR is imperfect.** Blurry photos, glare, curved packaging, and small
  print all degrade extraction accuracy. Always verify the auto-filled
  values against the physical label before relying on results.
- **Defaults are population averages**, not personalized measurements.
  For meaningful accuracy, enter your own age, height, weight, and
  (if known) body-fat percentage rather than relying on defaults.

**This tool is not a substitute for professional medical, dietary, or
diabetes-management advice.** If you have diabetes, insulin resistance,
an eating disorder, or any other metabolic condition, consult a
qualified healthcare provider before making decisions based on this app.

---

## Suggested future enhancements

A few ideas that would meaningfully improve usability beyond the current
scope:

- **Daily meal log & trends** — beyond one-off saved foods, log what was
  actually *eaten* with a timestamp, and chart cumulative insulin load
  and caloric balance over a day/week (the `foods` table could grow a
  companion `meal_log` table referencing it).
- **Barcode scanning fallback** — for packaged foods, look up
  Open Food Facts by barcode as a higher-accuracy alternative to OCR, and
  auto-fill brand/category from the lookup.
- **Per-user accounts** — the current database is single-user/local; a
  hosted DB (see the note above) plus simple auth would let each person
  have their own saved-food library.
- **Personalized insulin sensitivity input** — let users with a known
  HOMA-IR or clinical insulin-sensitivity value scale the estimate.
- **Multi-language OCR** — add `easyocr` or `tesseract` language packs for
  non-English labels.
- **Offline PWA support** — cache the app shell so it's usable with a
  spotty connection while grocery shopping.
- **Export/share results** — let users export a scan as PDF/image to
  share with a dietitian.

---

## Testing

```bash
pip install pytest
pytest tests/ -v
```

85 unit tests cover:
- Unit conversions (kg↔lb, ft/in↔cm)
- BMI, Deurenberg body-fat %, Mifflin-St Jeor BMR/TDEE (including
  known-value checks and edge cases: zero height, negative inputs,
  unknown activity levels)
- Profile default-filling logic (blank fields → baseline values)
- Insulin Load scoring and category boundaries
- TEF and gross-calorie derivation (label value vs. macro-derived
  fallback)
- Body-fat change projection for both surplus and deficit scenarios,
  plus the zero-weight guard
- OCR regex parsing against clean, noisy, partial, decimal-comma, and
  garbage/empty English text inputs
- **Japanese label parsing**: clean labels, OCR-inserted-whitespace
  tolerance, the 糖質+食物繊維 carbohydrate-breakdown fallback (and that a
  direct 炭水化物 total correctly takes precedence over it), full-width
  digit normalization, mixed English/Japanese labels, and the 蛋白質
  kanji variant for protein
- **Image preprocessing**: EXIF orientation correction (including a
  round-trip through a real JPEG with an orientation tag), huge-image
  downscaling, small-image upscaling, Otsu binarization producing
  pure black/white output, RGBA input handling, and that multiple
  preprocessing variants are generated per photo
- Food database: save/retrieve/delete, required-name validation, search
  by name/category/brand/tags individually and combined (AND logic
  across filters, ANY-match within tags), result ordering and limits,
  and autocomplete value lookups (including empty-database and
  duplicate/whitespace-tag edge cases)

All 85 tests pass. The app was also smoke-tested end-to-end: launched
headlessly from multiple working directories, confirmed a clean HTTP 200
boot with no runtime exceptions, and run through the full image → OCR →
parse → predict pipeline using a clear synthetic label (7/7 fields),
a synthetic label rotated 90° with a real EXIF orientation tag (verified
this fails completely — 0/7 fields — without the orientation fix, and
recovers to 7/7 with it), and a Japanese label (verified the initial
whitespace-tolerance bug — 3/7 fields — and its fix — 7/7 fields — with a
real OCR run against rendered Japanese text). The autocomplete fields
were specifically designed and tested against a real Streamlit edge case:
an empty-options `st.selectbox`/`st.multiselect` with
`accept_new_options=True` can disable free-text entry in some versions,
so those fields fall back to a plain text input until at least one value
exists to suggest — and each fallback mode uses a distinct widget key so
the field can never crash from a session-state type mismatch as the
option pool grows between reruns.

---

## License / attribution

Formulas used are drawn from publicly available nutrition-science
literature (Mifflin-St Jeor 1990; Deurenberg et al. 1991; Food Insulin
Index research, Bao et al. 2009 and related work). No proprietary or
licensed clinical algorithms are used.
