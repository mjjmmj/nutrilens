"""NutriLens application modules."""
